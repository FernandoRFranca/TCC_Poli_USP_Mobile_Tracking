-- SQLite
SELECT * FROM telemetria